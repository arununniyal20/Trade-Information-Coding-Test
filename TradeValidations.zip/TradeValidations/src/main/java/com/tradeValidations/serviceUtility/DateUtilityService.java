package com.tradeValidations.serviceUtility;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateUtilityService
{
    public static LocalDate getDateFromString(String inputDate)
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate date = LocalDate.parse(inputDate, formatter);
        return date;
    }

    public static boolean isWeekEnd(String inputDate)
    {
        LocalDate date = getDateFromString(inputDate);
        return (date.getDayOfWeek().compareTo(DayOfWeek.SATURDAY) == 0 | date.getDayOfWeek().compareTo(DayOfWeek.SUNDAY) == 0);
    }

    public static boolean isNonWorkingDay(String currency, String date)
    {
        return NonWorkingDay.isNonWorkingDay(currency, getDateFromString(date));
    }
}
