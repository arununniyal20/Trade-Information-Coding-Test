package com.tradeValidations.validator;

public enum ErrorCode
{

    VALUE_DATE_BEFORE_TRADE_DATE("Value date cannot be before trade date"), INVALID_DATE_FORMATE("Invalid date formate, system accepct only YYYY-MM-DD"),
    EXCERCISE_DATE_INCORRECT("Excercise Date is correct: it should be after the trade date but before the expiry date"),
    EXPIRY_AND_PREMIUM_DATE_INCORRECT("Expiry date and premium date shall be before delivery date"),
    EXPIRY_DATE_INCORRECT("Expiry date shall be before delivery date"), PREMIUM_DATE_INCORRECT("Premium date shall be before delivery date"),
    VALUE_DATE_CANNOT_BE_LIE_IN_WEEK_END("Value date cannot fall on weekend or non-working day for pay currency"),
    INVALID_TRADE_CURRENCY_CODE("Trade currency should be valid"), INVALID_PREMIUM_CURRENCY_CODE("Premium currency should be valid"),
    INVALID_CUSTOMERS("Invalid customer: Supported counterparties (customers) are : JUPITER1, JUPITER2"),
    INVALID_STYLE("The style can be either American or European"),
    VALUE_DTAE_REQUIRE_FOR_PRODUCT_TYPE_SPOT_AND_FORWARD("Value date require for profuct type SPOT, FORWARD"), NO_ERRORS("No Error");

    private final String description;

    private ErrorCode(String description)
    {
        this.description = description;
    }

    public String getDescription()
    {
        return description;
    }

}
