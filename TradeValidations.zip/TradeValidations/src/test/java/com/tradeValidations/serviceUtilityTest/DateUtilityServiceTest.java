package com.tradeValidations.serviceUtilityTest;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Test;

import com.tradeValidations.serviceUtility.DateUtilityService;


public class DateUtilityServiceTest
{

    @Test(expected = Exception.class)
    public void testInvalidDateFormatter()
    {
        DateUtilityService.getDateFromString("2017/07/19");
    }

    @Test(expected = Exception.class)
    public void testInvalidDate()
    {
        DateUtilityService.getDateFromString("2017-June-25");
    }

    @Test
    public void testValidDateWithVaildFormatter()
    {
        DateUtilityService.getDateFromString("2017-12-25");
    }

    @Test
    public void testLocalDate()
    {
        LocalDate date = LocalDate.now();
        LocalDate utilityDate = null;
        if (date.getMonthValue() > 9)
        {
            utilityDate = DateUtilityService.getDateFromString("" + date.getYear() + "-" + date.getMonthValue() + "-" + date.getDayOfMonth());
        }
        else
        {
            utilityDate = DateUtilityService.getDateFromString("" + date.getYear() + "-0" + date.getMonthValue() + "-" + date.getDayOfMonth());
        }
        Assert.assertTrue(date.equals(utilityDate));
    }

    @Test
    public void testInvalidWeekEnd()
    {
        Assert.assertFalse(DateUtilityService.isWeekEnd("2017-07-25"));
    }

    @Test
    public void testValidWeekEnd()
    {
        Assert.assertTrue(DateUtilityService.isWeekEnd("2017-07-22"));
    }
}
