package com.tradeValidations.oam.service.impl;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicLong;

import com.tradeValidations.oam.service.CountersService;

public final class CountersServiceImpl implements CountersService, Serializable
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private final AtomicLong successfulRecords;
    private final AtomicLong failedRecords;
    private final AtomicLong minimumRequestProcessingTime;
    private final AtomicLong maximumRequestProcessingTime;

    private static CountersService countersService;

    private CountersServiceImpl()
    {
        successfulRecords = new AtomicLong();
        failedRecords = new AtomicLong();
        minimumRequestProcessingTime = new AtomicLong();
        maximumRequestProcessingTime = new AtomicLong();
    }

    public static synchronized CountersService getInstanceOfCountersService()
    {
        if (countersService == null)
        {
            countersService = new CountersServiceImpl();
        }
        return countersService;
    }

    public AtomicLong getSuccessfulRecords()
    {
        return successfulRecords;
    }

    public AtomicLong getFailedRecords()
    {
        return failedRecords;
    }

    public AtomicLong getMinimumRequestProcessingTime()
    {
        return minimumRequestProcessingTime;
    }

    public AtomicLong getMaximumRequestProcessingTime()
    {
        return maximumRequestProcessingTime;
    }

}
