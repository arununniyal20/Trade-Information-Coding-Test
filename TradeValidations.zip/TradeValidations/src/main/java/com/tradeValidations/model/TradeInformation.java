package com.tradeValidations.model;

public interface TradeInformation
{
    public String getCustomer();

    public void setCustomer(String customer);

    public String getCcyPair();

    public void setCcyPair(String ccyPair);

    public String getType();

    public void setType(String type);

    public String getDirection();

    public void setDirection(String direction);

    public String getTradeDate();

    public void setTradeDate(String tradeDate);

    public String getAmount1();

    public void setAmount1(String amount1);

    public String getAmount2();

    public void setAmount2(String amount2);

    public String getRate();

    public void setRate(String rate);

    public String getValueDate();

    public void setValueDate(String valueDate);

    public String getLegalEntity();

    public void setLegalEntity(String legalEntity);

    public String getTrader();

    public void setTrader(String trader);

    public String getStyle();

    public void setStyle(String style);

    public String getExcerciseDate();

    public void setExcerciseDate(String excerciseDate);

    public String getStrategy();

    public void setStrategy(String strategy);

    public String getRadeDate();

    public void setRadeDate(String radeDate);

    public String getDeliveryDate();

    public void setDeliveryDate(String deliveryDate);

    public String getExpiryDate();

    public void setExpiryDate(String expiryDate);

    public String getPayCcy();

    public void setPayCcy(String payCcy);

    public String getPremium();

    public void setPremium(String premium);

    public String getPremiumCcy();

    public void setPremiumCcy(String premiumCcy);

    public String getPremiumType();

    public void setPremiumType(String premiumType);

    public String getPremiumDate();

    public void setPremiumDate(String premiumDate);
    
    public String getErrors();

    public void setErrors(String errors);
}
