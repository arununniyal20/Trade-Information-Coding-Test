package com.tradeValidations.validator;

import java.util.Currency;

import com.tradeValidations.model.TradeInformation;

public class CurrencyValidator extends AbstractValidator
{

    public CurrencyValidator(TradeInformation tradeInfo, ErrorStatus errorStatus)
    {
        super(tradeInfo, errorStatus);
    }

    @Override
    public void validate()
    {
        TradeInformation tradeInformation = getTradeInformation();
        if (tradeInformation.getPayCcy() != null && !tradeInformation.getPayCcy().isEmpty() && isValidCurrency(tradeInformation.getPayCcy()))
        {
            registerError(ErrorCode.INVALID_TRADE_CURRENCY_CODE.getDescription());
        }
        if (tradeInformation.getPremiumCcy() != null && !tradeInformation.getPremiumCcy().isEmpty() && isValidCurrency(tradeInformation.getPremiumCcy()))
        {
            registerError(ErrorCode.INVALID_PREMIUM_CURRENCY_CODE.getDescription());
        }
    }

    private boolean isValidCurrency(String currency)
    {
        try
        {
            return Currency.getInstance(currency) == null;
        }
        catch (IllegalArgumentException e)
        {
            return true;
        }
    }

}
