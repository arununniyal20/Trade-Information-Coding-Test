package com.tradeValidations.validator;

import com.tradeValidations.model.TradeInformation;

public class CustomerValidator extends AbstractValidator
{

    public CustomerValidator(TradeInformation tradeInfo, ErrorStatus errorStatus)
    {
        super(tradeInfo, errorStatus);
    }

    @Override
    public void validate()
    {
        TradeInformation tradeInfo = getTradeInformation();
        if (tradeInfo.getCustomer() != null && !tradeInfo.getCustomer().isEmpty())
        {
            for (CUSTOMERS eachCustomer : CUSTOMERS.values())
            {
                if (eachCustomer.name().equalsIgnoreCase(tradeInfo.getCustomer()))
                {
                    return;
                }
            }
            registerError(ErrorCode.INVALID_CUSTOMERS.getDescription());
        }
    }
    
    public enum CUSTOMERS
    {
        JUPITER1, JUPITER2
    }

}
