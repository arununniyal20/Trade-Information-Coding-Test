package com.tradeValidations.validator;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import com.tradeValidations.model.TradeInformation;
import com.tradeValidations.serviceUtility.DateUtilityService;

public class OptionSpecificValidator extends AbstractValidator
{

    public OptionSpecificValidator(TradeInformation tradeInfo, ErrorStatus errorStatus)
    {
        super(tradeInfo, errorStatus);
    }

    @Override
    public void validate()
    {
        TradeInformation tradeInfo = getTradeInformation();
        if (tradeInfo.getStyle() == null || tradeInfo.getStyle().isEmpty())
        {
            return;
        }
        if (isVaildStyle(tradeInfo.getStyle().toUpperCase()) && tradeInfo.getStyle().equals(STYLE.AMERICAN.name()))
        {
            try
            {
                validateExcerciseDateWithTradeDateAndExpiryDate(tradeInfo);
                validateExpiryDateAndPremiumDateWithDeliveryDate(tradeInfo);
            }
            catch (DateTimeParseException e)
            {
                registerError(ErrorCode.INVALID_DATE_FORMATE.getDescription());
            }
        }
    }

    private void validateExpiryDateAndPremiumDateWithDeliveryDate(TradeInformation tradeInfo) throws DateTimeParseException
    {
        if (tradeInfo.getExpiryDate() != null && tradeInfo.getPremiumDate() != null && tradeInfo.getDeliveryDate() != null)
        {
            LocalDate expiryDate = DateUtilityService.getDateFromString(tradeInfo.getExpiryDate());
            LocalDate premiumDate = DateUtilityService.getDateFromString(tradeInfo.getPremiumDate());
            LocalDate deliverDate = DateUtilityService.getDateFromString(tradeInfo.getDeliveryDate());

            if (expiryDate.isAfter(deliverDate) && premiumDate.isAfter(deliverDate))
            {
                registerError(ErrorCode.EXPIRY_AND_PREMIUM_DATE_INCORRECT.getDescription());
            }
            else if (expiryDate.isAfter(deliverDate))
            {
                registerError(ErrorCode.EXPIRY_DATE_INCORRECT.getDescription());
            }
            else if (premiumDate.isAfter(deliverDate))
            {
                registerError(ErrorCode.PREMIUM_DATE_INCORRECT.getDescription());
            }
        }
    }

    private void validateExcerciseDateWithTradeDateAndExpiryDate(TradeInformation tradeInfo) throws DateTimeParseException
    {
        if (tradeInfo.getExcerciseDate() != null && tradeInfo.getTradeDate() != null && tradeInfo.getExpiryDate() != null)
        {
            LocalDate excerciseDate = DateUtilityService.getDateFromString(tradeInfo.getExcerciseDate());
            LocalDate tradeDate = DateUtilityService.getDateFromString(tradeInfo.getTradeDate());
            LocalDate expiryDate = DateUtilityService.getDateFromString(tradeInfo.getExpiryDate());
            if (!(excerciseDate.isAfter(tradeDate) && excerciseDate.isBefore(expiryDate)))
            {
                registerError(ErrorCode.EXCERCISE_DATE_INCORRECT.getDescription());
            }
        }
    }

    private boolean isVaildStyle(String style)
    {
        for (STYLE eachStyle : STYLE.values())
        {
            if (eachStyle.name().equals(style))
            {
                return true;
            }
        }
        registerError(ErrorCode.INVALID_STYLE.getDescription());
        return false;
    }

    public enum STYLE
    {
        AMERICAN, EUROPEAN
    }
}
