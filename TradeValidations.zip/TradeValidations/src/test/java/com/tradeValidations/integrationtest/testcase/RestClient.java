package com.tradeValidations.integrationtest.testcase;

import java.io.IOException;
import java.io.InputStream;

import javax.ws.rs.core.Response;

import com.tradeValidations.service.impl.BulkTradeServiceImpl;

public class RestClient
{

    public Response validations(InputStream jsonPayload) throws IOException
    {
        try
        {
            String formatterResponse = ConversionUtility.getFormattedStringFromInputStream(jsonPayload);

            return new BulkTradeServiceImpl().validateResource(formatterResponse);
        }
        finally
        {
            jsonPayload.close();

        }
    }

}
