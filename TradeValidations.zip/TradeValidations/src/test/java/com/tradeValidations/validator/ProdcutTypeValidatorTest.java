package com.tradeValidations.validator;

import org.junit.Assert;
import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;

import com.tradeValidations.model.TradeInformation;
import com.tradeValidations.validator.ErrorStatus;
import com.tradeValidations.validator.ProdcutTypeValidator;

public class ProdcutTypeValidatorTest
{

    @Test
    public void testInvalidProductType()
    {
        TradeInformation tradeInfo = PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getType()).thenReturn("SPOT");
        ErrorStatus errorStatus = new ErrorStatus();
        new ProdcutTypeValidator(tradeInfo, errorStatus).validate();
        Assert.assertFalse(errorStatus.isErrorStatusOk());
    }

    @Test
    public void testValidProductType()
    {
        TradeInformation tradeInfo = PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getType()).thenReturn("SPOT");
        PowerMockito.when(tradeInfo.getValueDate()).thenReturn("2017-07-21");
        ErrorStatus errorStatus = new ErrorStatus();
        new ProdcutTypeValidator(tradeInfo, errorStatus).validate();
        Assert.assertTrue(errorStatus.isErrorStatusOk());
    }
}
