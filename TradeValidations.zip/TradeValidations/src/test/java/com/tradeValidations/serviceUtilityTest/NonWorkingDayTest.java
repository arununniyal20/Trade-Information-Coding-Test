package com.tradeValidations.serviceUtilityTest;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Test;

import com.tradeValidations.serviceUtility.DateUtilityService;
import com.tradeValidations.serviceUtility.NonWorkingDay;

public class NonWorkingDayTest
{

    @Test
    public void testFailedNonWorkinDay()
    {
        LocalDate date = DateUtilityService.getDateFromString("2017-07-23");
        Assert.assertFalse(NonWorkingDay.isNonWorkingDay("INR", date));
    }
    
    @Test
    public void testValidNonWorkinDay()
    {
        LocalDate date = DateUtilityService.getDateFromString("2017-07-24");
        Assert.assertTrue(NonWorkingDay.isNonWorkingDay("INR", date));
    }
}
