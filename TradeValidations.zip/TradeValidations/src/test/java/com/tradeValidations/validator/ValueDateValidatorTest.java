package com.tradeValidations.validator;

import org.junit.Assert;
import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;

import com.tradeValidations.model.TradeInformation;
import com.tradeValidations.validator.ErrorStatus;
import com.tradeValidations.validator.ValueDateValidator;

public class ValueDateValidatorTest
{
    @Test(expected = Exception.class)
    public void testInvalidValueDate()
    {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getValueDate()).thenReturn("EUROPEAN");
        ErrorStatus errorStatus = new ErrorStatus();
        new ValueDateValidator(tradeInfo,errorStatus).validate();
        Assert.assertFalse(errorStatus.isErrorStatusOk());
    }
    
    @Test
    public void testValueDateBeforeTradeDate()
    {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getValueDate()).thenReturn("2017-07-20");
        PowerMockito.when(tradeInfo.getTradeDate()).thenReturn("2017-07-21");
        ErrorStatus errorStatus = new ErrorStatus();
        new ValueDateValidator(tradeInfo,errorStatus).validate();
        Assert.assertFalse(errorStatus.isErrorStatusOk());
    }
    
    @Test
    public void testValueDateAfterTradeDate()
    {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getValueDate()).thenReturn("2017-07-21");
        PowerMockito.when(tradeInfo.getTradeDate()).thenReturn("2017-07-20");
        ErrorStatus errorStatus = new ErrorStatus();
        new ValueDateValidator(tradeInfo,errorStatus).validate();
        Assert.assertTrue(errorStatus.isErrorStatusOk());
    }
}
