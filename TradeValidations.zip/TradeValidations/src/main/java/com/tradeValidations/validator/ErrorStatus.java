package com.tradeValidations.validator;

import java.util.ArrayList;
import java.util.List;

public class ErrorStatus
{

    private boolean isErrorStatusOk;
    private List<String> errors;

    public ErrorStatus()
    {
        initilize();
    }

    private void initilize()
    {
        isErrorStatusOk = true;
        errors = new ArrayList<String>();
    }

    public boolean isErrorStatusOk()
    {
        return isErrorStatusOk;
    }

    public void setErrorStatusOk(boolean isErrorStatusOk)
    {
        this.isErrorStatusOk = isErrorStatusOk;
    }

    public List<String> getErrors()
    {
        return errors;
    }

    public void setErrors(List<String> error)
    {
        this.errors = error;
    }

    public boolean isErrorStatusNotOk()
    {
        return isErrorStatusOk == false;
    }

    public void resetErrorStatus()
    {
        isErrorStatusOk = true;
        this.errors.clear();
    }

}
