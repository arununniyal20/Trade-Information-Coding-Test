package com.tradeValidations.validator;

import com.tradeValidations.model.TradeInformation;

public abstract class AbstractValidator
{
    private TradeInformation tradeInformation;
    private ErrorStatus errorStatus;

    public AbstractValidator(TradeInformation tradeInfor, ErrorStatus errorStatus)
    {
        this.tradeInformation = tradeInfor;
        this.errorStatus = errorStatus;
    }

    public abstract void validate();

    public ErrorStatus getErrorStatus()
    {
        return errorStatus;
    }

    public TradeInformation getTradeInformation()
    {
        return tradeInformation;
    }

    public void setTradeInformation(TradeInformation tradeInfo)
    {
        this.tradeInformation = tradeInfo;
    }
    
    protected void registerError(String errorMessage) {
        getErrorStatus().setErrorStatusOk(false);
        getErrorStatus().getErrors().add(errorMessage);
    }
}
