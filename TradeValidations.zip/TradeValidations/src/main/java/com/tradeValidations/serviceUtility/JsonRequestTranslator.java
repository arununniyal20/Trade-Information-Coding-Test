package com.tradeValidations.serviceUtility;

import java.lang.reflect.Type;

import com.google.gson.Gson;

public class JsonRequestTranslator
{

    private final Gson myGson;

    public JsonRequestTranslator(Gson gson)
    {
        myGson = gson;
    }

    public String javaObjectTojsonObject(Object handlerName)
    {
        return myGson.toJson(handlerName);
    }

    public <T> Object jsonObjectToJavaObject(String jsonPayload, Type type)
    {
        return myGson.fromJson(jsonPayload, type);

    }

}
