package com.tradeValidations.oam.service;

import java.util.concurrent.atomic.AtomicLong;

public interface CountersService {

    public AtomicLong getSuccessfulRecords();

    public AtomicLong getFailedRecords();
    
    public AtomicLong getMinimumRequestProcessingTime();
    
    public AtomicLong getMaximumRequestProcessingTime();
}
