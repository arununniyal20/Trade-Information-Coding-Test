package com.tradeValidations.service;

import javax.ws.rs.core.Response;

public interface BulkTradeService
{
    /**
     * This API will validate the list of trade informations as per given business rule requirements.
     * @param jsonPayload Json pay load coming in request.
     * @return the response 
     */
    public Response validateResource(String jsonPayload);
    
    public Response performanceMetrics();

}
