package com.tradeValidations.service;

public interface RestConstant
{
    String BACK_SLASH = "/";
    String INTERFACE_VERSION = "v1";
    String VALIDATE_RESOURCE = "validateRequestData";
    String VALIDATE_BATCH_RESOURCE = "validateBatchRequestData";
    String SUCCESS = "Vaild Input";
    String NO_ERRORS = "No Error";
    String SPERETAE = ", ";
    String PERFORMANCE = "performance";
}