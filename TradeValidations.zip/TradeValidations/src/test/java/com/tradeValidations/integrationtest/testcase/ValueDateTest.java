package com.tradeValidations.integrationtest.testcase;

import java.io.IOException;
import java.net.URL;

import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tradeValidations.service.RestConstant;
import com.tradeValidations.validator.ErrorCode;

public class ValueDateTest extends AbstractFlowTest
{

    private static final Logger LOG = LoggerFactory.getLogger(ValueDateTest.class);

    @Test
    public void testValueDateCannotBeBeforeTradeDate()
    {
        try
        {
            URL url = fecthJsonResourcesFromPath("valueDateBeforeTradeDateTest.json");
            Response response = myRestClient.validations(url.openStream());
            Assert.assertTrue(ErrorCode.VALUE_DATE_BEFORE_TRADE_DATE.getDescription().equals(getDataFromResponse(response,"errors")));
        }
        catch (IOException e)
        {
            LOG.error(e.getLocalizedMessage());
            e.printStackTrace();
        }
    }
    
    @Test
    public void testValueDateCannotBeBeforeFallOnWeekEnd()
    {
        try
        {
            URL url = fecthJsonResourcesFromPath("valueDateCannotBeFallOnWeekEnd.json");
            Response response = myRestClient.validations(url.openStream());
            Assert.assertTrue(ErrorCode.VALUE_DATE_CANNOT_BE_LIE_IN_WEEK_END.getDescription().equals(getDataFromResponse(response,"errors")));
        }
        catch (IOException e)
        {
            LOG.error(e.getLocalizedMessage());
            e.printStackTrace();
        }
    }
}
