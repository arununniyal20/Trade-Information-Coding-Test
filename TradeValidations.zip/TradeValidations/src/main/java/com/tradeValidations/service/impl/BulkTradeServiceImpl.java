package com.tradeValidations.service.impl;

import java.lang.reflect.Type;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tradeValidations.model.TradeInformation;
import com.tradeValidations.model.impl.TradeInformationImpl;
import com.tradeValidations.service.BulkTradeService;
import com.tradeValidations.service.RestConstant;
import com.tradeValidations.serviceUtility.JsonRequestTranslator;
import com.tradeValidations.validator.AbstractValidator;
import com.tradeValidations.validator.CurrencyValidator;
import com.tradeValidations.validator.CustomerValidator;
import com.tradeValidations.validator.OptionSpecificValidator;
import com.tradeValidations.validator.ProdcutTypeValidator;
import com.tradeValidations.validator.ValueDateValidator;

@Path("/tradeValidations")
public class BulkTradeServiceImpl extends ValidationsCommonService implements BulkTradeService
{
    @POST
    @Path(RestConstant.BACK_SLASH + RestConstant.INTERFACE_VERSION + RestConstant.BACK_SLASH + RestConstant.VALIDATE_RESOURCE)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(
    {
            MediaType.APPLICATION_JSON
    })
    public Response validateResource(String jsonPayload)
    {
        Instant startingTime = Instant.now();
        Response response = null;
        boolean isErrorFound = false;
        try
        {
            Type tradeType = new TypeToken<Collection<TradeInformationImpl>>()
            {
            }.getType();

            @SuppressWarnings("unchecked")
            List<TradeInformation> tradeList = (List<TradeInformation>) new JsonRequestTranslator(new Gson()).jsonObjectToJavaObject(jsonPayload, tradeType);

            for (TradeInformation eachObject : tradeList)
            {
                validateResource(eachObject);
                if (errorStatus.isErrorStatusOk())
                {
                    eachObject.setErrors(RestConstant.NO_ERRORS);
                }
                else
                {
                    StringBuilder errors = new StringBuilder();
                    for (String eachValue : errorStatus.getErrors())
                    {
                        errors.append(eachValue + RestConstant.SPERETAE);
                    }
                    eachObject.setErrors(errors.delete(errors.length() - 2, errors.length()).toString());
                    isErrorFound = true;
                    errorStatus.resetErrorStatus();
                }
            }

            if (isErrorFound)
            {
                response = generateFailureResponse(isErrorFound ? Status.NOT_ACCEPTABLE : Status.OK,
                        new JsonRequestTranslator(new Gson()).javaObjectTojsonObject(tradeList));
            }
            else
            {
                response = generateSuccessResponse(Status.OK, new JsonRequestTranslator(new Gson()).javaObjectTojsonObject(tradeList));
            }
        }
        catch (IllegalStateException exception)
        {
            response = generateFailureResponse(Status.BAD_REQUEST, exception.getLocalizedMessage());
        }
        validateAndUpdateRequestProcessingTime(Duration.between(startingTime, Instant.now()).toMillis());
        return response;
    }

    private void validateResource(TradeInformation tradeInfo)
    {    
        for(AbstractValidator each: getValidators(tradeInfo)) {
            each.validate();
        }     
    }

    private List<AbstractValidator> getValidators(TradeInformation tradeInfo)
    {
        return Arrays.asList(new ValueDateValidator(tradeInfo, errorStatus), new CustomerValidator(tradeInfo, errorStatus),
                new CurrencyValidator(tradeInfo, errorStatus), new ProdcutTypeValidator(tradeInfo, errorStatus),
                new OptionSpecificValidator(tradeInfo, errorStatus));
    }

    @GET
    @Path(RestConstant.BACK_SLASH + RestConstant.INTERFACE_VERSION + RestConstant.BACK_SLASH + RestConstant.PERFORMANCE)
    @Produces(
    {
            MediaType.APPLICATION_JSON
    })
    public Response performanceMetrics()
    {
        return Response.status(Status.OK).entity(new JsonRequestTranslator(new Gson()).javaObjectTojsonObject(getMyCountersService()))
                .header(CONTENT_TYPE, MediaType.APPLICATION_JSON).build();
    }
}
