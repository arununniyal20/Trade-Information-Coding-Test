package com.tradeValidations.integrationtest.testcase;

import java.io.IOException;
import java.net.URL;

import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tradeValidations.service.RestConstant;
import com.tradeValidations.validator.ErrorCode;

public class OptionSpecificTest extends AbstractFlowTest
{
    private static final Logger LOG = LoggerFactory.getLogger(OptionSpecificTest.class);

    @Test
    public void testInvalidExcerciseDate()
    {
        try
        {
            URL url = fecthJsonResourcesFromPath("excerciseDateBeforeTradeDateAndAfterExpiryDate.json");
            Response response = myRestClient.validations(url.openStream());
            Assert.assertTrue(ErrorCode.EXCERCISE_DATE_INCORRECT.getDescription().equals(getDataFromResponse(response,"errors")));
        }
        catch (IOException e)
        {
            LOG.error(e.getLocalizedMessage());
        }
    }
    
    @Test
    public void testValidExcerciseDate()
    {
        try
        {
            URL url = fecthJsonResourcesFromPath("excerciseDateAfterTradeDateAndBeforeExpiryDate.json");
            Response response = myRestClient.validations(url.openStream());
            Assert.assertTrue(RestConstant.NO_ERRORS.equals(getDataFromResponse(response,"errors")));
        }
        catch (IOException e)
        {
            LOG.error(e.getLocalizedMessage());
        }
    }
    
    @Test
    public void testInvalidDeliveryDate()
    {
        try
        {
            URL url = fecthJsonResourcesFromPath("expiryDateAndPremiumDateAfterDeliveryDate.json");
            Response response = myRestClient.validations(url.openStream());
            Assert.assertTrue(ErrorCode.EXPIRY_AND_PREMIUM_DATE_INCORRECT.getDescription().equals(getDataFromResponse(response,"errors")));
        }
        catch (IOException e)
        {
            LOG.error(e.getLocalizedMessage());
        }
    }
    
    @Test
    public void testValidDeliveryDate()
    {
        try
        {
            URL url = fecthJsonResourcesFromPath("expiryDateAndPremiumDateBeforeDeliveryDate.json");
            Response response = myRestClient.validations(url.openStream());
            Assert.assertTrue(RestConstant.NO_ERRORS.equals(getDataFromResponse(response,"errors")));
        }
        catch (IOException e)
        {
            LOG.error(e.getLocalizedMessage());
        }
    }
}
