package com.tradeValidations.integrationtest.testcase;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class ConversionUtility
{

    public static String getFormattedStringFromInputStream(InputStream incomeInput)
    {
        BufferedReader br = null;
        StringBuilder sb = new StringBuilder();
        String line;
        try
        {

            br = new BufferedReader(new InputStreamReader(incomeInput));
            while ((line = br.readLine()) != null)
            {
                sb.append(line);
            }

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (br != null)
            {
                try
                {
                    br.close();
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }
        return String.format(sb.toString().replaceAll(Pattern.quote("%"), ""));
    }

    public static <T> Object objectToArrayConversion(Object incomeInput, T type)
    {
        return null;
    }
}
