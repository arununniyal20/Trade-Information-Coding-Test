package com.tradeValidations.validator;

import org.junit.Assert;
import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;

import com.tradeValidations.model.TradeInformation;
import com.tradeValidations.validator.CustomerValidator;
import com.tradeValidations.validator.ErrorStatus;

public class CustomerValidatorTest
{
    @Test
    public void testInvalidCustomer() {
        TradeInformation mock =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(mock.getCustomer()).thenReturn("Test");
        ErrorStatus errorStatus = new ErrorStatus();
        new CustomerValidator(mock,errorStatus).validate();
        Assert.assertFalse(errorStatus.isErrorStatusOk());
    }
    
    @Test
    public void testValidCustomer() {
        TradeInformation mock =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(mock.getCustomer()).thenReturn("JUPITER1");
        ErrorStatus errorStatus = new ErrorStatus();
        new CustomerValidator(mock,errorStatus).validate();
        Assert.assertTrue(errorStatus.isErrorStatusOk());
    }
}
