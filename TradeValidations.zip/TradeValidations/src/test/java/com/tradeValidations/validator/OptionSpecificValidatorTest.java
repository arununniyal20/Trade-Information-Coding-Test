package com.tradeValidations.validator;

import org.junit.Assert;
import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;

import com.tradeValidations.model.TradeInformation;
import com.tradeValidations.validator.ErrorStatus;
import com.tradeValidations.validator.OptionSpecificValidator;

public class OptionSpecificValidatorTest
{

    @Test
    public void testFailedTradeInfomrationOptionStyle()
    {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getStyle()).thenReturn("EUROPEAN");
        ErrorStatus errorStatus = new ErrorStatus();
        new OptionSpecificValidator(tradeInfo,errorStatus).validate();
        Assert.assertFalse(errorStatus.isErrorStatusNotOk());
    }

    @Test
    public void testInvalidExcerciseDate()
    {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getStyle()).thenReturn("AMERICAN");
        PowerMockito.when(tradeInfo.getExcerciseDate()).thenReturn("2017-07-21");
        PowerMockito.when(tradeInfo.getTradeDate()).thenReturn("2017-07-22");
        PowerMockito.when(tradeInfo.getExpiryDate()).thenReturn("2017-07-19");
        ErrorStatus errorStatus = new ErrorStatus();
        new OptionSpecificValidator(tradeInfo,errorStatus).validate();
        Assert.assertFalse(errorStatus.isErrorStatusOk());
    }

    @Test
    public void testValidExcerciseDate()
    {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getStyle()).thenReturn("AMERICAN");
        PowerMockito.when(tradeInfo.getExcerciseDate()).thenReturn("2017-07-21");
        PowerMockito.when(tradeInfo.getTradeDate()).thenReturn("2017-07-19");
        PowerMockito.when(tradeInfo.getExpiryDate()).thenReturn("2017-07-25");
        ErrorStatus errorStatus = new ErrorStatus();
        new OptionSpecificValidator(tradeInfo,errorStatus).validate();
        Assert.assertTrue(errorStatus.isErrorStatusOk());
    }

    @Test
    public void testExpiryDateAndPremiumDate()
    {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getStyle()).thenReturn("AMERICAN");
        PowerMockito.when(tradeInfo.getExcerciseDate()).thenReturn("2017-07-21");
        PowerMockito.when(tradeInfo.getTradeDate()).thenReturn("2017-07-19");
        PowerMockito.when(tradeInfo.getExpiryDate()).thenReturn("2017-07-25");
        PowerMockito.when(tradeInfo.getPremiumDate()).thenReturn("2017-07-24");
        PowerMockito.when(tradeInfo.getDeliveryDate()).thenReturn("2017-07-28");
        ErrorStatus errorStatus = new ErrorStatus();
        new OptionSpecificValidator(tradeInfo,errorStatus).validate();
        Assert.assertTrue(errorStatus.isErrorStatusOk());
    }

    @Test
    public void testInvalidExpiryDateAndPremiumDate()
    {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getStyle()).thenReturn("AMERICAN");
        PowerMockito.when(tradeInfo.getExcerciseDate()).thenReturn("2017-07-21");
        PowerMockito.when(tradeInfo.getTradeDate()).thenReturn("2017-07-19");
        PowerMockito.when(tradeInfo.getExpiryDate()).thenReturn("2017-07-25");
        PowerMockito.when(tradeInfo.getPremiumDate()).thenReturn("2017-07-24");
        PowerMockito.when(tradeInfo.getDeliveryDate()).thenReturn("2017-07-21");
        ErrorStatus errorStatus = new ErrorStatus();
        new OptionSpecificValidator(tradeInfo,errorStatus).validate();
        Assert.assertFalse(errorStatus.isErrorStatusOk());
    }
}
