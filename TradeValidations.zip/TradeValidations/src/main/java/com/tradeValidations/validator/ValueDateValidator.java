package com.tradeValidations.validator;

import java.text.ParseException;
import java.time.LocalDate;

import com.tradeValidations.model.TradeInformation;
import com.tradeValidations.serviceUtility.DateUtilityService;

public class ValueDateValidator extends AbstractValidator
{

    public ValueDateValidator(TradeInformation tradeInfo, ErrorStatus errorStatus)
    {
        super(tradeInfo, errorStatus);
    }

    @Override
    public void validate()
    {
        try
        {
            TradeInformation tradeInformation = getTradeInformation();
            if (tradeInformation.getValueDate() != null && !tradeInformation.getValueDate().isEmpty())
            {
                validateValueDateWithTradeDate();
                validateValueDateForNorWorkingDay();
            }
        }
        catch (ParseException e)
        {
            registerError(ErrorCode.INVALID_DATE_FORMATE.getDescription());
            e.printStackTrace();
        }
    }

    private void validateValueDateForNorWorkingDay() throws ParseException
    {
        TradeInformation tradeInformation = getTradeInformation();
        if (DateUtilityService.isWeekEnd(tradeInformation.getValueDate())
                || (tradeInformation.getPayCcy() != null && DateUtilityService.isNonWorkingDay(tradeInformation.getValueDate(), tradeInformation.getPayCcy())))
        {
            registerError(ErrorCode.VALUE_DATE_CANNOT_BE_LIE_IN_WEEK_END.getDescription());
        }
    }

    private void validateValueDateWithTradeDate() throws ParseException
    {
        TradeInformation tradeInformation = getTradeInformation();
        if (tradeInformation.getValueDate() != null && tradeInformation.getTradeDate() != null)
        {
            LocalDate valueDate = DateUtilityService.getDateFromString(tradeInformation.getValueDate());
            LocalDate tradeDate = DateUtilityService.getDateFromString(tradeInformation.getTradeDate());
            if (valueDate.isBefore(tradeDate))
            {
                registerError(ErrorCode.VALUE_DATE_BEFORE_TRADE_DATE.getDescription());
            }
        }

    }

}
