package com.tradeValidations.integrationtest.testcase;

import java.io.IOException;
import java.net.URL;

import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tradeValidations.service.RestConstant;

public class BulkValidationsTest extends AbstractFlowTest
{
    private static final Logger LOG = LoggerFactory.getLogger(BulkValidationsTest.class);

    @Test
    public void testValidateFailure()
    {     
        try
        {
            URL url = fecthJsonResourcesFromPath("bulkValidationsTest.json");
            Response response = myRestClient.validations(url.openStream());

            String bulkResponse = (String) response.getEntity();
            JsonArray responseArray = (JsonArray) new JsonParser().parse(bulkResponse);
            
            for(int index = 0;index<responseArray.size();index++) {
                Assert.assertTrue(RestConstant.NO_ERRORS.contains(((JsonObject) responseArray.get(0)).get("errors").getAsString()));
            }
         
        }
        catch (IOException e)
        {
            LOG.error(e.getLocalizedMessage());
        }
    }
}