package com.tradeValidations.service.impl;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.tradeValidations.oam.service.CountersService;
import com.tradeValidations.oam.service.impl.CountersServiceImpl;
import com.tradeValidations.validator.ErrorStatus;

public class ValidationsCommonService
{

    public static final String CONTENT_TYPE = "Content-Type";
    protected ErrorStatus errorStatus = new ErrorStatus();

    private CountersService myCountersService;

    public ValidationsCommonService()
    {
        myCountersService = CountersServiceImpl.getInstanceOfCountersService();
    }

    protected Response generateSuccessResponse(Status httpStatus, String responseJson)
    {
        myCountersService.getSuccessfulRecords().incrementAndGet();
        return makeResponse(httpStatus, responseJson);
    }

    private Response makeResponse(Status httpStatus, String jsonString)
    {
        return Response.status(httpStatus).entity(jsonString).header(CONTENT_TYPE, MediaType.APPLICATION_JSON).build();
    }

    protected Response generateFailureResponse(Status httpStatus, String responseJson)
    {
        myCountersService.getFailedRecords().incrementAndGet();
        return makeResponse(httpStatus, responseJson);
    }

    protected void validateAndUpdateRequestProcessingTime(long reuestProcessingTime) {
        validateAndUpdaetMinimumRequestProcessingTime(reuestProcessingTime);
        validateAndUpdaetMaximumRequestProcessingTime(reuestProcessingTime);
    }

    private void validateAndUpdaetMinimumRequestProcessingTime(long reuestProcessingTime)
    {
        if (myCountersService.getMinimumRequestProcessingTime().get() == 0 || myCountersService.getMinimumRequestProcessingTime().get() > reuestProcessingTime)
        {
            myCountersService.getMinimumRequestProcessingTime().set(reuestProcessingTime);
        }
    }

    protected void validateAndUpdaetMaximumRequestProcessingTime(long reuestProcessingTime)
    {
        if (myCountersService.getMaximumRequestProcessingTime().get() == 0 || myCountersService.getMaximumRequestProcessingTime().get() < reuestProcessingTime)
        {
            myCountersService.getMaximumRequestProcessingTime().set(reuestProcessingTime);
        }
    }

    public CountersService getMyCountersService()
    {
        return myCountersService;
    }
    
}
