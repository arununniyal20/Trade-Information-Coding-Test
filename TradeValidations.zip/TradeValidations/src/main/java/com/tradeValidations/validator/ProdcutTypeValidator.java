package com.tradeValidations.validator;

import com.tradeValidations.model.TradeInformation;

public class ProdcutTypeValidator extends AbstractValidator
{

    public ProdcutTypeValidator(TradeInformation tradeInfo, ErrorStatus errorStatus)
    {
        super(tradeInfo, errorStatus);
    }

    @Override
    public void validate()
    {
        TradeInformation tradeInfo = getTradeInformation();
        if (tradeInfo.getType() != null && !tradeInfo.getType().isEmpty() && isProductTypeSpotOrForward(tradeInfo.getType().toUpperCase()))
        {
            if (tradeInfo.getValueDate() == null || tradeInfo.getValueDate().isEmpty())
            {
                registerError(ErrorCode.VALUE_DTAE_REQUIRE_FOR_PRODUCT_TYPE_SPOT_AND_FORWARD.getDescription());
            }
        }
    }

    private boolean isProductTypeSpotOrForward(String style)
    {
        for (PRODUCT_TYPE eachProduct : PRODUCT_TYPE.values())
        {
            if (eachProduct.name().equals(style))
            {
                return true;
            }
        }
        return false;
    }

    public enum PRODUCT_TYPE
    {
        SPOT, FORWARD
    }
}
