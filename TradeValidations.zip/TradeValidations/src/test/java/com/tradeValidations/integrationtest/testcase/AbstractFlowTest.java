package com.tradeValidations.integrationtest.testcase;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import javax.ws.rs.core.Response;

import org.junit.Before;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public abstract class AbstractFlowTest
{

    protected RestClient myRestClient;

    @Before
    public void init()
    {
        if (myRestClient == null)
        {
            myRestClient = new RestClient();
        }
    }
    
    protected URL fecthJsonResourcesFromPath(String tradeURL) throws MalformedURLException
    {
        return new File(this.getClass().getClassLoader().getResource(tradeURL).getFile()).toURI().toURL();
    }
    
    protected String getDataFromResponse(Response tradeResponse,String columnName) {
        String jsonResponse = (String) tradeResponse.getEntity();
        JsonArray jsonArray = (JsonArray) new JsonParser().parse(jsonResponse);
        return ((JsonObject) jsonArray.get(0)).get(columnName).getAsString();
    }
}
