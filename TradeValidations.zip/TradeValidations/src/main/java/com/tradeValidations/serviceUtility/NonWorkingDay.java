package com.tradeValidations.serviceUtility;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NonWorkingDay
{
    static Map<String, List<DayOfWeek>> nonWorkingCalander = new HashMap<String, List<DayOfWeek>>();

    static
    {
        nonWorkingCalander.put("USD", Arrays.asList(DayOfWeek.FRIDAY, DayOfWeek.MONDAY));
        nonWorkingCalander.put("EUR", Arrays.asList(DayOfWeek.MONDAY, DayOfWeek.TUESDAY));
        nonWorkingCalander.put("JPY", Arrays.asList(DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY));
        nonWorkingCalander.put("GBP", Arrays.asList(DayOfWeek.THURSDAY, DayOfWeek.FRIDAY));
        nonWorkingCalander.put("INR", Arrays.asList(DayOfWeek.FRIDAY, DayOfWeek.MONDAY));
        nonWorkingCalander.put("KWD", Arrays.asList(DayOfWeek.FRIDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY));
    }

    public static boolean isNonWorkingDay(String currency, LocalDate date)
    {
        List<DayOfWeek> nonWorkingDay = nonWorkingCalander.get(currency);
        for (DayOfWeek eachDay : nonWorkingDay)
        {
            if (date.getDayOfWeek().compareTo(eachDay) == 0)
            {
                return true;
            }
        }
        return false;
    }
}