package com.tradeValidations.validator;

import org.junit.Assert;
import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;

import com.tradeValidations.model.TradeInformation;
import com.tradeValidations.validator.CurrencyValidator;
import com.tradeValidations.validator.ErrorStatus;

public class CurrencyValidatorTest
{
    @Test
    public void testInvalidPayCurrency() {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getPayCcy()).thenReturn("INVALID");
        ErrorStatus errorStatus = new ErrorStatus();
        new CurrencyValidator(tradeInfo,errorStatus).validate();
        Assert.assertFalse(errorStatus.isErrorStatusOk());
    }
    
    @Test
    public void testValidPayCurrency() {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getPayCcy()).thenReturn("INR");
        ErrorStatus errorStatus = new ErrorStatus();
        new CurrencyValidator(tradeInfo,errorStatus).validate();
        Assert.assertTrue(errorStatus.isErrorStatusOk());
    }
    
    @Test
    public void testInvalidPremiumCurrency() {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getPremiumCcy()).thenReturn("INVALID");
        ErrorStatus errorStatus = new ErrorStatus();
        new CurrencyValidator(tradeInfo,errorStatus).validate();
        Assert.assertFalse(errorStatus.isErrorStatusOk());
    }
    
    @Test
    public void testValidPremiumCurrency() {
        TradeInformation tradeInfo =PowerMockito.mock(TradeInformation.class);
        PowerMockito.when(tradeInfo.getPremiumCcy()).thenReturn("PLN");
        ErrorStatus errorStatus = new ErrorStatus();
        new CurrencyValidator(tradeInfo,errorStatus).validate();
        Assert.assertTrue(errorStatus.isErrorStatusOk());
    }
}
